package org.goldenorb;


public interface VerticesRPCProtocol {
  Vertices sendAndReceive(Vertices vs);
}
