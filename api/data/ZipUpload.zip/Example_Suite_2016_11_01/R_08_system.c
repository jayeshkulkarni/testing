/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#include "mc3_types.h"
#include "mc3_header.h"


int main ( void )
{
  R_8_1 ( );
  R_8_2 ( );
  R_8_3 ( );
  R_8_4 ( );
  R_8_5 ( );
  R_8_6 ( );
  R_8_7 ( );
  R_8_8 ( );
  R_8_9 ( );
  R_8_10 ( );
  R_8_11 ( );
  R_8_12 ( );
  R_8_13 ( );
  R_8_14 ( );

  R_8_main_support ( );
  return 0;
}

/* end of R_08_system.c */

