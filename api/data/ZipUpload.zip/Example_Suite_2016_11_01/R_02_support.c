/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_2_main_support ( void )
{
  R_2_1 ( );
  R_2_2 ( );
  R_2_3 ( );
  R_2_4 ( );
  R_2_5 ( );
  R_2_6 ( );
  R_2_7 ( );
}

/* end of R_02_support.c */

