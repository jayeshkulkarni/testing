/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_11_main_support ( void )
{
  R_11_1 ( );
  R_11_2 ( );
  R_11_3 ( );
  R_11_4 ( );
  R_11_5 ( );
  R_11_6 ( );
  R_11_7 ( );
  R_11_8 ( );
  R_11_9 ( );
}

/* end of R_11_support.c */

