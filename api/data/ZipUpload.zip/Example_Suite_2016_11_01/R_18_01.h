/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#ifndef R_18_01_
#define R_18_01_

#include "mc3_types.h"
#include "mc3_header.h"


#endif /* R_18_01_ */

