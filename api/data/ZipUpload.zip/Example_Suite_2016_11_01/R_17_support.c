/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/* Support file so that external functions are called more than once */

#include "mc3_types.h"
#include "mc3_header.h"


void R_17_main_support ( void )
{
  R_17_1 ( );
  R_17_2 ( );
  R_17_3 ( );
  R_17_4 ( );
  R_17_5 ( );
  R_17_6 ( );
  R_17_7 ( );
  R_17_8 ( );
}

/* end of R_17_support.c */

