/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/*
 * D.2.1
 *
 * All source files shall compile without any compilation errors
 */


/* There are no examples for this guideline */

/* end of D_02_01.c */

