/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#ifndef R_15_07_
#define R_15_07_

#include "mc3_types.h"
#include "mc3_header.h"

extern void action_f1 ( void );
extern void action_f2 ( void );

#endif /* R_15_07_ */
