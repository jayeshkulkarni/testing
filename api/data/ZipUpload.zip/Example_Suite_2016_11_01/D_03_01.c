/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

/*
 * D.3.1
 *
 * All code shall be traceable to documented requirements
 */


/* There are no examples for this guideline */

/* end of D_03_01.c */

