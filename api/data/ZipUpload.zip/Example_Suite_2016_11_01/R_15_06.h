/*
 * Release: 2016-01-01
 *
 * Example from MISRA C:2012 ( THIS IS NOT A TEST SUITE )
 *
 * Copyright HORIBA MIRA Limited.
 *
 * See file READ_ME.txt for full copyright, license and release instructions.
 */

#ifndef R_15_06_
#define R_15_06_

#include "mc3_types.h"
#include "mc3_header.h"

extern void action_1 ( void );
extern void action_2 ( void );
extern bool_t fn ( void );
extern bool_t process_data ( void );

#endif /* R_15_06_ */
